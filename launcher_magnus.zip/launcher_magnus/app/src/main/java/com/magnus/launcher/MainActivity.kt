package com.magnus.launcher

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnGPS = findViewById<Button>(R.id.btn_gps)
        val btnBLE = findViewById<Button>(R.id.btn_ble)
        val btnWiFi = findViewById<Button>(R.id.btn_wifi)
        val btnSettings = findViewById<Button>(R.id.btn_settings)
        val btnShutdown = findViewById<Button>(R.id.btn_shutdown)
        val btnReboot = findViewById<Button>(R.id.btn_reboot)

        btnGPS.setOnClickListener {
            launchApp("com.aura.chronometer")
        }

        btnBLE.setOnClickListener {
            toggleBluetooth()
        }

        btnWiFi.setOnClickListener {
            toggleWiFi()
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        }

        btnShutdown.setOnClickListener {
            shutdown()
        }

        btnReboot.setOnClickListener {
            reboot()
        }
    }

    private fun launchApp(packageName: String) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "App non trouvée", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleBluetooth() {
        try {
            val intent = Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Ouverture Bluetooth...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur BLE", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleWiFi() {
        try {
            val intent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Ouverture WiFi...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur WiFi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shutdown() {
        try {
            Runtime.getRuntime().exec("su -c 'shutdown -p now'")
        } catch (e: Exception) {
            Toast.makeText(this, "Shutdown requiert root", Toast.LENGTH_SHORT).show()
        }
    }

    private fun reboot() {
        try {
            Runtime.getRuntime().exec("su -c 'reboot'")
        } catch (e: Exception) {
            Toast.makeText(this, "Reboot requiert root", Toast.LENGTH_SHORT).show()
        }
    }
}
